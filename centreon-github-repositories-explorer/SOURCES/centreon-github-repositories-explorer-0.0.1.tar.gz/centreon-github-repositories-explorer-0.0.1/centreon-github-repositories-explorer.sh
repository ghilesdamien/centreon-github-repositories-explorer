#!/bin/bash
#Getting Centreon GitHub repositories
curl "https://api.github.com/users/centreon/repos?per_page=100"
